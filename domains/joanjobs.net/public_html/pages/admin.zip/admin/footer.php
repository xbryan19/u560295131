</div> 
 <footer id="main-footer" class="footer mt-5 py-5 bg-dark text-white">
    <div class="container">
      <div class="row text-center">
        <div class="col">
		  <p class="lead">Job Outsourcing Nasugbu</p>
          <p class="lead">Copyrights &copy; 2018</p>
        </div>
      </div>
    </div>
  </footer>
 <style>
  .page-item.active .page-link {
  background-color: #717772;
border-color: #161817;
} 
</style> 
<script src="../../js/jquery.min.js"></script>
<script src="../../datatables/datatables/js/jquery.dataTables.min.js"></script>

<!-- DataTables JavaScript -->

<script src="../../datatables/datatables/js/dataTables.bootstrap4.min.js"></script>
<script src="../../datatables/responsive/js/responsive.bootstrap4.js"></script>

<script src="../../js/bootstrap.min.js"></script>
<script src="../../js/tether.min.js"></script> 