

<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <a class="navbar-brand" href="#">JOAN</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
	<li class="nav-item">
        <a class="nav-link" href="index.php">Home</a>
      </li>   
	 <li class="nav-item">
        <a class="nav-link" href="applicants.php">Applicants</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="jobposts.php">Jobs</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="employerlist.php">Employers</a>
      </li>    
	     <li class="nav-item">
        <a class="nav-link" href="about.php">About Us</a>
      </li>    
    </ul>
	
	
		<ul class="navbar-nav nav ml-auto"> 
		  <li class="nav-item">
        <a class="nav-link" href="register.php">Registration</a>
      </li>    
 
		</ul>
		
  </div>  
</nav>