<style>
div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 300px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 300px;
  height: 170px;
}

div.desc {
  padding: 15px;
  text-align: center;
}


.goshine{color:red}

</style>
